# Daily Content Drops

Auto-generated every morning at 6:00 AM by the [content engine](../templates/content-engine.md). Newest at the top. Each drop is a ready-to-use, compliance-safe content brief for DGD ambassadors.

> Skim with coffee → pick one idea → run a [workflow](../tools/workflows.md) → [pre-publish checklist](../templates/pre-publish-checklist.md).

## Latest drops
Newest first. The daily task prepends each new entry below.

<!-- DROP-LINKS -->
- [2026-06-16](2026-06-16.md) — seed/example drop (sets the format): trend radar, Veo spotlight, 3 idea sets, prompt of the day.
