---
tags: [templates, series, content-ideas]
updated: 2026-06-16
---

# Series Ideas — Pre-Built Content Arcs

Series build audience and make batching easy. Each below is multiple videos from one theme. All are educational; none sell. Pair with [content calendar](content-calendar-and-series.md).

## 1. "The 6 Rules of Real Money" (6–8 videos) ⭐ best starter
- Ep 0: "There are 6 things real money needs — most currencies fail one."
- Ep 1–6: one [pillar](../dgd/six-pillars.md) each (Scarcity, Stable Pricing, Free Adoption, Decentralized Governance, Freedom to Transact, Adequate Circulation).
- Ep 7: "How one project tries to hit all six." (overview, design framing only)
- Consistent intro/outro; number them ("Rule 3 of 6").

## 2. "Money, Explained" (evergreen, open-ended)
- What even is money? · Why it loses value · Who decides what it's worth · The whale problem · What "Layer-1" means · Fee burning · Code-enforced scarcity.
- One [glossary](../dgd/glossary.md) term per short.

## 3. "Sound Money Thinkers" (3–5 videos)
- Carl Menger: where money comes from · Mises: why monopoly money debases · Hayek: let currencies compete · "What they'd say about crypto."

## 4. "Is It Really Money?" (myth-busters)
- "Most crypto payments aren't money — the 5-second test" · "More coins ≠ more value" · "Why every altcoin follows Bitcoin" · "Holding isn't spending."

## 5. "Measuring Value" (CFV/DGSB, 3–4 videos)
- Why crypto never had a yardstick · The frozen-Bitcoin benchmark · The 4 numbers that matter · Why adoption is weighted 70%.
- Frame strictly as **measurement**, never "undervalued." → [valuation](../dgd/valuation-cfv-dgsb.md)

## 6. "Inflation 101" (relatable, high-share)
- The 96% stat · The 2% target = half your savings in 35 years · Grocery-bill-over-time · "Why your raise isn't a raise."

## 7. "How I Make These" (meta / behind-the-scenes)
- Your free AI workflow, the tools, why you disclose AI + sponsorship. Builds trust and recruits other creators. Naturally transparent.

## 8. "Casino vs Money" (anti-degen, high-reach)
- Recurring contrast format: a degen behavior (chasing pumps, apeing memecoins, being exit liquidity) vs the sound-money alternative.
- Hooks like "Tired of getting rekt?" Speak *to* the degen audience; never sell a degen play. → [positioning & audiences](../craft/positioning-and-audiences.md)

## 9. "Is It a Security?" (safe-harbor explainers)
- Run the digital-commodity test, the Howey test, the 2026 safe-harbor framework. Deeply on-brand and surprisingly bingeable. → [safe-harbor page](../dgd/positioning-safe-harbor.md)
- Episodes: "What's a digital commodity?" · "The phras