---
tags: [tools, images, thumbnails]
updated: 2026-06-16
verified: 2026-06
---

# Step 3b — AI Images & Thumbnails (Free)

Still images for b-roll, title cards, diagrams, and cover frames.

## Free image generators (Jun 2026)

| Tool | Free tier | Commercial use | Watermark | Best for |
|---|---|---|---|---|
| **Bing Image Creator** (DALL·E 3) | ~15 fast generations/day | Personal; check MS terms for commercial | None visible | Quick, high quality, free |
| **Google Gemini (Imagen)** | ~15/day | Permitted, no watermark | None | Photorealistic, in Google stack |
| **Adobe Firefly** | 25 credits/mo | **Commercially safe** outputs | None | Lowest legal risk; trained on licensed data |
| **Leonardo AI** | ~150 tokens/day (20–40 images) | Free plan allows commercial (verify) | None | Most model variety, styles |
| **Ideogram** | Free generations | **Commercial requires paid** | — | Best **text inside images** |
| **Canva (free) Magic Media** | Limited free | With Canva's content license | — | Generate + design in one place |

## Recommendations
- **Lowest-risk pick:** **Adobe Firefly** — outputs are designed to be commercially safe. Good when content is monetized/sponsored.
- **Best free quality:** **Bing Image Creator** or **Gemini/Imagen**.
- **Need words rendered cleanly in the image** (a title card that says "SOUND MONEY")? **Ideogram** (or just add text in CapCut/Canva to avoid AI-spelling errors).

## Thumbnails & title cards (the compliance trap)
Your thumbnail and on-screen title are **subject to the same rules** as your script. A perfect video with a **"🚀 DGD TO $100K 🤑"** thumbnail still violates the [communications discipline](../compliance/communications-discipline.md) and platform financial rules.

**Safe thumbnail/title formulas:**
- "Why money loses value 📉" (curiosity, no claim)
- "The 6 rules of REAL money"
- "Is this even money? 🤔"
- "Inflation, explained in 30s"

**Unsafe:** anything with price targets, rockets-to-the-moon, dollar-stacks-with-gains framing, "get rich," "early."

## Quick design tips
- Big, legible text (3–5 words max), high contrast.
- One focal subject; faces/eyes draw clicks but keep it honest.
- Consistent brand look across a series builds recognition.
- Free design app: **Canva** (templates, text, simple editing).

## Images you'll reuse a lot
Build a small library: gold/coins, eroding cash, supply-chain icons, network graphs, portraits-of-economists style cards, "fixed rules" lock imagery, a clean DGD-neutral color palette title template.

## Connects to
- [Image & video prompts](../prompts/image-and-video-prompts.md) · [Captions & editing](captions-and-editing.md) · [Platform specs](../craft/platform-specs.md)
- Compliance: [do & don't language](../compliance/do-and-dont-language.md)
