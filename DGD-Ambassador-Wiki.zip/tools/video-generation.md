---
tags: [tools, video-generation, ai-video]
updated: 2026-06-16
verified: 2026-06
---

# Step 3 — AI Video Generation (Free)

Generate b-roll, scenes, and motion from text or images. **Realistic AI video must be labeled** on every platform. → [AI disclosure](../compliance/ai-disclosure.md)

## Free tools (Jun 2026)

| Tool | Free tier | Watermark on free? | Audio? | Notes |
|---|---|---|---|---|
| **Google Veo (via Gemini app / Google Flow)** | ~10–20 generations/mo on free Google account; 720p | No (Veo 3 free exports) | Yes (native) | Top quality; easiest if you have a Google account |
| **Kling AI** (klingai.com) | ~66 daily credits (3–5 clips), reset 24h | Yes on free | Some models | Very powerful; generous daily refresh |
| **Hailuo AI** (MiniMax) | Daily free credits | Yes on free | Some | Fast generations |
| **Pika** (pika.art) | 250 starter credits | No watermark on free | — | Good for stylized motion |
| **Pixverse** | Daily free credits | Varies | — | Refreshes daily |
| **Vheer / Wan Video** | Unlimited image→video, no sign-up | Varies | — | Fastest free entry; quality varies |
| **Runway** (free tier) | Limited credits | Yes on free | — | Strong editor features |

## Picking a tool
- **Have a Google account?** Start with **Veo via Gemini** — best quality, no watermark on free Veo exports, native audio.
- **Need volume / daily output?** **Kling** or **Hailuo** daily credits (mind the watermark — crop or cover, or upgrade).
- **Want watermark-free stylized clips?** **Pika**.
- **Just need quick image-to-motion b-roll?** **Vheer / Wan**.

## What to actually generate for DGD videos
You rarely need AI to fake a person. For educational money content, generate **abstract and illustrative b-roll** that's safe and on-theme:
- Gold bars, coins, vaults, flowing particles (scarcity, value)
- Eroding/melting cash, shrinking stacks (inflation — illustrative, not a real person)
- Supply-chain montage: factory → truck → store (circulation)
- Abstract network/node animations (decentralization)
- Historical-style market floors, printing presses (monetary history)

**This avoids the riskiest AI-disclosure category** (realistic fake people/events) while still looking great. Stylized/abstract motion is usually not "realistic" enough to require a label — but when in doubt, label it.

## Hard "don't" for AI video
- ❌ Don't generate **realistic fake footage of real public figures** (e.g., a central banker "admitting" something). High legal + platform risk, and it can attribute false quotes to real people.
- ❌ Don't fabricate "news" clips or real events.
- ✅ Do keep AI visuals illustrative, and **label realistic synthetic media**.

## Prompts
Ready-to-use video prompts (gold, inflation, supply chain, network themes) are in [image-and-video-prompts.md](../prompts/image-and-video-prompts.md).

## Connects to
- Prev → [Voiceover](voiceover-tts.md) · Pair with → [Images & thumbnails](images-and-thumbnails.md) · Next → [Captions & editing](captions-and-editing.md)
- [AI disclosure](../compliance/ai-disclosure.md)
