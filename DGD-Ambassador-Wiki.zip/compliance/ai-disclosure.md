---
tags: [compliance, ai, disclosure]
updated: 2026-06-16
verified: 2026-06
---

# AI-Content Disclosure — Labeling Synthetic Media

Every major platform now requires you to **label realistic AI-generated or altered content.** Since this wiki is all about making video with AI tools, this matters on most of your posts.

## The simple rule

**Label it when AI makes something *realistic* that a viewer could mistake for real** — a real-looking person, voice, place, or event. You generally **don't** need to label AI used as **production assistance** (idea generation, scripting, outlines, captions, basic editing).

| AI use | Disclose? |
|---|---|
| AI **script / ideas / outline / title** | ❌ No |
| AI **captions / basic edit / b-roll cleanup** | ❌ No (production assistance) |
| AI **voiceover that sounds like a real person** | ✅ Yes |
| AI **avatar / talking head / face** | ✅ Yes |
| **Realistic AI video** of people/places/events | ✅ Yes |
| Altering real footage to look different than reality | ✅ Yes |
| Obvious cartoons, clearly-stylized animation, abstract motion graphics | Usually ❌ (not "realistic") |

## Platform by platform

### YouTube (Shorts included)
Disclosure of "meaningfully altered or synthetically generated" realistic content is **mandatory** (fully enforced since May 21, 2025). At upload, in YouTube Studio → details → **"Altered content" → Yes**. YouTube adds a "Modified or Synthetic" note. If you use YouTube's **own built-in generative effects**, disclosure is handled automatically. Repeatedly skipping required disclosure can mean forced labels, warnings, removal, or YPP suspension. Takes <30 seconds.

### TikTok
Toggle the **AI-generated content** label when content is realistic AI. TikTok also auto-labels some AI content via provenance signals (C2PA).

### Instagram / Meta
Meta applies **"AI info"** labeling to realistic AI imagery/video and expects creators to disclose. Add your own on-screen note for realistic synthetic media.

### X (Twitter)
X has a **"Made with AI"** label and a **"Manipulated Media"** tag. Labeling is largely creator-disclosed for now, but unlabeled synthetic media can be flagged/penalized — X has enforced hard against undisclosed AI video in sensitive categories.

## Belt-and-suspenders best practice

Beyond the platform toggle, **add a tiny on-screen note** ("AI-generated visuals" / "AI voice") for any realistic synthetic media. It protects you across every platform when you cross-post, and it builds audience trust.

## Why bother

- It's required; non-compliance risks removal and demonetization.
- DGD content is financial-adjacent and educational — credibility is everything. A "this uses an AI voice" note costs you nothing and signals honesty.
- It pairs naturally with your [FTC disclosure](ftc-disclosure.md) and "not financial advice" note.

## Connects to
- [Voiceover / TTS tools](../tools/voiceover-tts.md) · [Video generation tools](../tools/video-generation.md) · [Platform policies](platform-policies.md)
- [Pre-publish checklist](../templates/pre-publish-checklist.md)

*Platform policies change often — verify at each platform's help center before relying on this.*
