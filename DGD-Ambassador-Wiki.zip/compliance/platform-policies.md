---
tags: [compliance, platforms, tos]
updated: 2026-06-16
verified: 2026-06
---

# Platform Policies — TikTok, Instagram, YouTube, X

What each platform allows and forbids around **crypto/financial content**, **branded content**, and **AI disclosure**. Read the row for every platform you post to. Cross-posting the same video means you must satisfy the **strictest** platform's rules.

## The universal takeaways

1. **Educational crypto content is generally allowed. Promoting a specific coin to buy is generally not.** Your job — educational explainers — is on the right side of this line *if you keep the [communications discipline](communications-discipline.md)*.
2. **All four platforms require disclosure of branded content** (you're rewarded → it's branded). → [FTC disclosure](ftc-disclosure.md)
3. **All four expect AI-content labels** on realistic synthetic media. → [AI disclosure](ai-disclosure.md)
4. **No investment promises, ever** — also a platform rule, not just the Foundation's.

---

## TikTok

**Crypto/financial:** TikTok's **Branded Content Policy prohibits** branded content that promotes **cryptocurrency and financial services/products** (loans, trading platforms, forex, get-rich-quick schemes, etc.) for ordinary creators. In the US, TikTok **allows educational content about blockchain and crypto** but **prohibits direct promotion of individual cryptocurrencies or trading platforms**, and bars investment promises / risk-minimizing language. Only licensed, regulated entities can run crypto *ads*, via an application process.

**What this means for you:** Frame everything as **education about money and blockchain**, not promotion of DGD as a product to buy. Don't use the **branded-content toggle to promote DGD as a financial product** — that's the prohibited combination. Disclose your material connection in-video and in caption regardless. Avoid "buy/trade/invest" language entirely (you already do — see [do & don't](do-and-dont-language.md)).

**AI:** Toggle the AI-generated label for realistic AI media.

**Risk note:** TikTok is the **strictest** here. If a video would be borderline on TikTok, it's borderline everywhere — fix it.

---

## Instagram Reels (Meta)

**Crypto/financial:** Organic educational content is allowed; Meta restricts **financial-product ads** and applies extra scrutiny to "sensitive categories." Branded content promoting financial products faces tighter approval workflows.

**Branded content:** Use the built-in **Paid Partnership** label (creator tags the brand; brand approves → "Paid partnership with…" appears under your handle). For **Reels specifically**, caption labels aren't enough — include a **spoken disclosure in the first 3 seconds** plus a **high-contrast on-screen text overlay**. (FTC + Meta both expect in-video disclosure for video.)

**AI:** Meta applies "AI info" labels to realistic AI media; disclose and add your own note.

---

## YouTube Shorts

**Crypto/financial:** Educational crypto explainers are well-supported and searchable. Avoid content that promises returns or solicits investment (can trigger "harmful or dangerous" / spam-and-deceptive scrutiny, especially financial scams).

**Paid promotion:** Tick **"contains paid promotion"** in upload settings; YouTube shows a "Includes paid promotion" disclosure. Still add your own spoken + on-screen disclosure.

**AI:** **Mandatory** altered/synthetic disclosure for realistic AI (YouTube Studio → "Altered content"). Built-in YouTube AI effects self-disclose. → [AI disclosure](ai-disclosure.md)

**Bonus:** Shorts reward **replays, shares, like-to-view, CTR** more than raw watch time — see [viral principles](../craft/viral-principles.md).

---

## X (Twitter)

**Crypto/financial:** Native crypto audience; educational content thrives. The Foundation's own channel is **@DigitalGoldTalk**. X is rolling out crypto-aware "Smart Cashtags" with live price data — be aware your post may render alongside price data, which makes price-talk discipline even more important.

**Branded content:** X has added **paid partnership labels** — use them.

**AI:** "Made with AI" label + "Manipulated Media" tag; disclose realistic synthetic media.

**Automation:** If you schedule/automate posts, follow X's automation rules (no spammy duplicate posting). → [workflows](../tools/workflows.md)

---

## Cross-posting matrix (quick glance)

| Requirement | TikTok | Instagram | YouTube | X |
|---|---|---|---|---|
| Educational crypto OK | ✅ | ✅ | ✅ | ✅ |
| Promote coin "to buy" | ❌ | ❌ (ads restricted) | ❌ | ⚠️ avoid |
| Branded-content label | ✅ required | ✅ Paid Partnership | ✅ paid promotion | ✅ paid partnership |
| In-video disclosure for video | ✅ | ✅ (first 3s) | ✅ | ✅ |
| AI realistic-media label | ✅ | ✅ | ✅ mandatory | ✅ |

**Rule:** satisfy the strictest cell in each row. In practice that means: educational framing + front-loaded disclosure + spoken & on-screen + AI label. Do that and you're clean everywhere.

## Connects to
- [FTC disclosure](ftc-disclosure.md) · [AI disclosure](ai-disclosure.md) · [Communications discipline](communications-discipline.md)
- [Platform specs (sizes, lengths)](../craft/platform-specs.md) · [Pre-publish checklist](../templates/pre-publish-checklist.md)

*Platform policies change frequently. Verify each platform's current Help Center / policy pages before relying on this page.*
