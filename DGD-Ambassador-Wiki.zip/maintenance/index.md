# Maintenance Log

Weekly verification reports land here, written every Monday by the [content engine](../templates/content-engine.md). Each report records what tool free-tiers and platform policies were re-checked, what changed, and which wiki pages were updated.

> The summary of each pass is also appended to the main [`log.md`](../log.md).

## Reports
_(None yet — the first will appear after the next Monday run.)_
